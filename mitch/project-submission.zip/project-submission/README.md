# Souffle with Lattices, C++ Generation

By Mitchel Myers (mtm387@psu.edu)
and Ryan Pasculano (rep5339@psu.edu)

Our final report is located in the file `final-report.pdf` next to this README.

Our code is available at https://github.com/doublemix/souffle
Instructions to build and test out our implementation can be found in the `README.md` of that repository.
